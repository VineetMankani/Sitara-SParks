console.log('khjl');
// const month = document.querySelector('.date h1');
// const dateString = document.querySelector('.date p');
// let monthDates = document.querySelector('.dates');
// const date = new Date();

// // let lastDay = new Date(date.getFullYear(), date.getMonth()+1, 0).getDate();
// // console.log(lastDay);

// const months = ['Januray', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

// month.innerText = months[date.getMonth()];
// dateString.innerText = date.toDateString();

// let onedate = "";

// for(let i = 1; i <= 31; i++) {
//     onedate += `<div>${i}</div>`;
//     monthDates.innerHTML = onedate;
// }